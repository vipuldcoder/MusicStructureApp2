package com.musicstructureapp.app.musicstructureapp;

public class AdapterItems {
    public int ID;
    public String Title;
    public String Artist;

    AdapterItems(int ID, String Title, String Artist) {
        this.ID = ID;
        this.Title = Title;
        this.Artist = Artist;
    }
}